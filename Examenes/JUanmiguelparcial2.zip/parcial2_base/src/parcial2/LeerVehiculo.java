package parcial2;

import java.io.BufferedReader;
import java.io.File;
import java.io.FileNotFoundException;
import java.io.FileReader;
import java.io.IOException;
import java.util.Scanner;

import javax.swing.JFileChooser;

import acm.program.*;

public class LeerVehiculo extends ConsoleProgram {
	public void run(){
		{
			
			JFileChooser fChooser = new JFileChooser(); // seleccione rendimiento.txt
			int result = fChooser.showOpenDialog(this);
			if(result == JFileChooser.APPROVE_OPTION){
				File archivo = fChooser.getSelectedFile();
				try{
					FileReader fReader = new FileReader(archivo);
					Scanner sc = new Scanner(fReader);
					int suma = 0;
					while(sc.hasNext()){
						String entrada = sc.next();
						println("La placa es"+entrada);
					}
					sc.close();
					fReader.close();
					
				}catch(FileNotFoundException e){
					println("EL archivo no se encontr�");
				}catch(IOException e){
					println("EL archivo pudo leerse");
				}
			}
		}

}
}
