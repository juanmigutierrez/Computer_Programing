package parcial2;
import java.io.File;
import java.io.FileNotFoundException;
import java.io.FileReader;
import java.io.IOException;
import java.util.Scanner;

import javax.swing.JFileChooser;

import acm.program.*;
import acm.util.RandomGenerator;

public class VehiculoApplet extends ConsoleProgram {
	public void run() {
		Vehiculo Nissan = new Vehiculo(Marca.Nissan ,"Sail","HGY");
		Camioneta Chevrolet = new Camioneta(Marca.Chevrolet ,"Primero Modelo","HGY", 4);
		Vehiculo Nissan2 = new Vehiculo(Marca.Nissan ,"Ultimo","HGY");
		Nissan.setplaca("HGY");
		Nissan2.setplaca("HGY");
		Chevrolet.setplaca("HGY");
		
		placas(Nissan.getplaca());
		
	}public String placas(String placas) {
		RandomGenerator ranGen = RandomGenerator.getInstance();
		int a = ranGen.nextInt(0,9);
		int b = ranGen.nextInt(0,9);
		int c = ranGen.nextInt(0,9);
		String placafinal =" ";
		Scanner sc = new Scanner(placas);
		if(sc.hasNext()) {
			String entrada = sc.next();
			placafinal = placafinal + entrada ;
			println(entrada);
			if(entrada == "H") {
				if(sc.hasNext()) {
					entrada = sc.next();
					placafinal = placafinal + entrada;
					println(entrada);
					if(entrada == "G") {
						entrada = sc.next();
						placafinal = placafinal + entrada;
						println(entrada);
						if(entrada =="Y") {
							entrada = sc.next();
							println(entrada);
							placafinal = placafinal + entrada + a + b +c ;
							println(placafinal);
							
						}
					}
				}
				
				
			}
		
		}return placafinal;
		
	}public String Archivo() {
	String a = " ";
	JFileChooser fChooser = new JFileChooser(); // seleccione rendimiento.txt
	int result = fChooser.showOpenDialog(this);
	if(result == JFileChooser.APPROVE_OPTION){
		File archivo = fChooser.getSelectedFile();
		try{
			FileReader fReader = new FileReader(archivo);
			Scanner sc = new Scanner(fReader);
			int suma = 0;
			while(sc.hasNext()){
				String entrada = sc.next();
				println("La placa es"+entrada);
				a = a + entrada;
				println(a);
			}
			sc.close();
			fReader.close();
			
		}catch(FileNotFoundException e){
			println("EL archivo no se encontr�");
		}catch(IOException e){
			println("EL archivo pudo leerse");
		}
	}return a;
			
		
	

}
}
