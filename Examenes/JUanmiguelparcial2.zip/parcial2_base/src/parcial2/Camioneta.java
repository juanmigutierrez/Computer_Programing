package parcial2;

public class Camioneta extends Vehiculo {
	private float capacidad;
	
	public Camioneta(Marca marca,String modelo,String placa, float capacidad) {
		super(marca,modelo,placa);
		this.capacidad = capacidad;
		
	}public void setcapacidad(float capacidad) {
		this.capacidad =capacidad;
		
	}public float getcapacidad() {
		return capacidad;
	}public boolean mas3Ton(float capacidad) {
		if(capacidad >= 3) {
			return true;
		}else {
			return false;
		}
		
	}

}
