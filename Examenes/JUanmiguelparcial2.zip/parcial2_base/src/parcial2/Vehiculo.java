package parcial2;

public class Vehiculo {
	private String modelo;
	private String placa;
	private Marca marca1;
	
	public Vehiculo(Marca marca,String modelo,String placa) {
		marca1 = marca;
		this.modelo = modelo;
		this.placa = placa;
	}
	public String getmodelo() {
		return modelo;
	}public String getplaca() {
		return placa;
	}public void setmodelo(String modelo) {
		this.modelo = modelo;
		
	}public void setplaca(String placa) {
		this.placa = placa;
	}public String toString() {
		return modelo + placa+ marca1 ;
	}
}
