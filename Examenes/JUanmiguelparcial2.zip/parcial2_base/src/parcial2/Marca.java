package parcial2;

public enum Marca {
	Chevrolet, Renault,Nissan;

}
