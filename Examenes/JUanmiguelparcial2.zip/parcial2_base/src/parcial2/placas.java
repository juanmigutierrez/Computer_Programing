package parcial2;
import java.util.Scanner;
import acm.util.*;

import acm.program.*;

public class placas extends ConsoleProgram {
	public void run() {
		String placas = "HGY123";
		placas(placas);
		
	}public String placas(String placas) {
		RandomGenerator ranGen = RandomGenerator.getInstance();
		int i = 0;
		int a = ranGen.nextInt(0,9);
		int b = ranGen.nextInt(0,9);
		int c = ranGen.nextInt(0,9);
		String placafinal =" ";
		Scanner sc = new Scanner(placas);
		if(sc.hasNext()) {
			String entrada = sc.next();
			placafinal = placafinal + entrada ;
			println(entrada);
			if(entrada == "H") {
				if(sc.hasNext()) {
					entrada = sc.next();
					placafinal = placafinal + entrada;
					println(entrada);
					if(entrada == "G") {
						entrada = sc.next();
						placafinal = placafinal + entrada;
						println(entrada);
						if(entrada =="Y") {
							entrada = sc.next();
							println(entrada);
							placafinal = placafinal + entrada + a + b +c ;
							println(placafinal);
							
						}
					}
				}
				
				
			}
		
		}return placafinal;
		
	}

}
