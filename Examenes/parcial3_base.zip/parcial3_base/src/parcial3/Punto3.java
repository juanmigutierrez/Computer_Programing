package parcial3;

public class Punto3 {

}
