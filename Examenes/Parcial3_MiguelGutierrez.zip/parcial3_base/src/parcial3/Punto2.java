package parcial3;
import java.io.BufferedReader;
import java.io.FileNotFoundException;
import java.io.FileReader;
import java.io.IOException;
import java.util.HashMap;
import java.util.StringTokenizer;

import acm.program.*;

public class Punto2 extends ConsoleProgram {
	
	HashMap<Integer,Integer> miMap;
	public void run() {
		miMap = new HashMap<Integer,Integer>();
		String linea1 = "In Penny Lane there is a barber showing photographs";
		String linea = "../data/pennylane.txt";
		leerString(linea);
		println(miMap.get(1));
		
	}public void leerString(String fullname) {
		try{
			FileReader fReader = new FileReader(fullname);
			BufferedReader bufReader = new BufferedReader(fReader);
			String linea = bufReader.readLine();
			Integer indice= 1;
			while(linea != null) {
				println(linea);
				Integer contiene = leerlinea(linea);
			    miMap.put(indice, contiene);
			    indice = indice +1 ;
			    linea = bufReader.readLine();
			}
			bufReader.close();
			
		}catch(FileNotFoundException e){
			println("EL archivo no se encontr�");
		}catch(IOException e){
			println("EL archivo pudo leerse");
		}
	
	}public int leerlinea(String linea) {
		Integer suma = 0;
		for(int i =0 ; i<=linea.length()-1;i++) {
			suma = suma +1;
		}return suma ;
	}
}
