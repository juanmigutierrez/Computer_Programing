package parcial3;

import java.util.ArrayList;

import acm.program.ConsoleProgram;

public class Punto1  extends ConsoleProgram{

	private double[] miArreglo = {2, 9, 4, 5, 1, 6, 2, 9, 12, 15, 42};
	ArrayList<Double> miLista;
	
	public void run(){
		miLista =new ArrayList<Double>();
		ordenarSeleccion(miArreglo);
		imprimirArreglo(miArreglo);
		miLista = new ArrayList<Double>();
		agregarlista(miArreglo);
		ponerb(miLista, 5);
		println(miLista);
		
	}
	
	
	
	
	
	private void ordenarSeleccion(double[] arreglo) {
		for(int izq = 0; izq < arreglo.length; izq++){
			int der = encontrarMenor(arreglo, izq, arreglo.length);
			intercambiarElementos(arreglo, izq, der); 
		}
	}
	
	/**
	 * Retorna el �ndice del menor elemento en el arreglo entre las posiciones p1 y p2-1
	 */
	private int encontrarMenor(double[] arreglo, int p1, int p2){
		int menorIndice = p1;
		for (int  i = p1+1; i<p2; i++){
			if(arreglo[i] < arreglo[menorIndice]) menorIndice = i;
		}
		return menorIndice;
	}
	
	
	private void intercambiarElementos(double[] arreglo, int p1, int p2){
		double temp = arreglo[p1];
		arreglo[p1] = arreglo[p2];
		arreglo[p2] = temp;
	}private void imprimirArreglo(double[] arreglo){
		println("---");
		for(int i = 0; i < arreglo.length; i++){
			println(arreglo[i]); 
		}
		println("---");
	}private void agregarlista(double[] arreglo) {
		for(int i = 0; i < arreglo.length; i++){
			miLista.add(arreglo[i]); 
		}
		
	}public void ponerb(ArrayList<Double> lista, double b) {
		for(int i = 0; i <= lista.size()+1; i++){
			if(b<miLista.get(i)) {
				miLista.add(i,b);
			}if(i==lista.size()+1) {
				miLista.add(i,b);
			}
			
		}
	}
	
	
}
