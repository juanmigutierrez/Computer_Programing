package parcial3;
import java.awt.event.ActionEvent;
import java.awt.event.MouseEvent;

import javax.swing.JButton;

import acm.graphics.GObject;
import acm.graphics.GOval;
import acm.graphics.GPoint;
import acm.program.*;


public class Punto3 extends GraphicsProgram {
	
	GOval circulo;
	JButton aumentar;
	JButton disminuir;
	private final static double tamano=25;
	private GObject obj;
	private GPoint ultimo;
	
    public void init() {
    	aumentar = new JButton("+");
    	disminuir = new JButton("-");
    	add(aumentar,SOUTH);
    	add(disminuir,SOUTH);
    	addMouseListeners();
		addActionListeners();
    	
    }public void mouseClicked(MouseEvent e){
    	if(obj ==null){
		GOval circulo1 = new GOval(tamano,tamano);
		circulo1.setFilled(true);
		add(circulo1, e.getX(), e.getY());
    	}
    	else if(obj!=null) {
    		ultimo = new GPoint(e.getPoint());
    		obj = getElementAt(ultimo);
    	}
		
	}public void mousePressed(MouseEvent e){
		ultimo = new GPoint(e.getPoint());
		obj = getElementAt(ultimo);
		circulo = (GOval) obj;
	}
	public void mouseDragged(MouseEvent e){
		if (obj !=null){
			obj.move(e.getX() - ultimo.getX(), e.getY() - ultimo.getY());
			circulo = (GOval) obj;
			ultimo = new GPoint(e.getPoint());
		}
	}public void actionPerformed(ActionEvent e){
		if(e.getActionCommand().equals("+")){
			aumentar();
		}else if(e.getActionCommand().equals("-")){
			disminuir();
		}
		
	}public void aumentar() {
		circulo.setSize(circulo.getWidth()+25,circulo.getHeight()+25);
	}public void disminuir() {
		circulo.setSize(circulo.getWidth()-25,circulo.getHeight()-25);
	}

}
