package punto1;
import acm.program.ConsoleProgram;
import acm.util.RandomGenerator;

public class punto1 extends ConsoleProgram {
public void run() {
	RandomGenerator ranGen=RandomGenerator.getInstance();
	int color = ranGen.nextInt(1,4);
	if(color==1) {
		println("La primera pinta que escogio es diamantes");
	}else if(color==2) {
		println("La primera pinta que escogio es picas");
	}else if(color==3) {
		println("La primera pinta que escogio es treboles");
	}else if(color==4) {
		println("La primera pinta que escogio es corazones");
	}
	int carta = ranGen.nextInt(1,13);
	int valor2 = valores(carta);
	
	int color2 = ranGen.nextInt(1,4);
	if(color2==1) {
		println("La pinta de la segunda carta que escogio es diamantes");
	}else if(color2==2) {
		println("La pinta de la segunda carta que escogio es picas");
	}else if(color2==3) {
		println("La pinta de la segunda carta que escogio es treboles");
	}else if(color2==4) {
		println("La pinta de la segunda carta que escogio es corazones");
	}
	int carta2 = ranGen.nextInt(1,13);
	int valor3 = valores(carta2);
	boolean iguales = igualdad(color,valor2,color2,valor3);
	while(iguales == true) {
		println("El sistema saco las misma cartas, entra a generar nueva carta...");
		carta2 = ranGen.nextInt(1,13);
		valor3 = valores(carta2);
		println("Usted ha sacado el valor "+valor3);
		color2 = ranGen.nextInt(1,4);
		if(color2==1) {
			println("La pinta de la segunda carta que escogio es diamantes");
		}else if(color2==2) {
			println("La pinta de la segunda carta que escogio es picas");
		}else if(color2==3) {
			println("La pinta de la segunda carta que escogio es treboles");
		}else if(color2==4) {
			println("La pinta de la segunda carta que escogio es corazones");
		}
	    iguales = igualdad(color,valor2,color2,valor3);
	}
	if (valor2 + valor3 == 21) {
		println("usted gano");
	} else {
		println("usted perdio");
		
	}
			
  }

private int valores( int n ) {
		int carta1 = n;
		switch(carta1) {
		case 1 :
			println("y la carta es un As");
			int valor = 11;
			return valor;
		case 2 :
			println("y la carta es un 2");
			valor = carta1;
			return valor;
		case 3 :
			println("y la carta es un 3");
			valor = carta1;
			return valor;
		case 4 :
			println("y la carta es un 4");
			valor = carta1;
			return valor;
		case 5 :
			println("y la carta es un 5");
			valor = carta1;
			return valor;
		case 6 :
			println("y la carta es un 6");
			valor = carta1;
			return valor;
		case 7 :
			println("y la carta es un 7");
			valor = carta1;
			return valor;
		case 8 :
			println("y la carta es un 8");
			valor = carta1;
			return valor;
		case 9 :
			println("y la carta es un 9");
			valor = carta1;
			return valor;
		case 10 :
			println("y la carta es un 10");
			valor = carta1;
			return valor;
		case 11 :
			println("y la carta es un J");
			valor = 10;
			return valor;
		case 12 :
			println("y la carta es un Q");
			valor = 10;
			return valor;
		case 13 :
			println("y la carta es un K");
			valor = 10;
			return valor;
		default:
			valor = 0;
			return valor;
		}
		
  }


private boolean igualdad(int a,int b ,int c , int d) {
	if(a==c && b==d ) {
		return true;
		
	}else {
		return false;
	}
	
}
	




}


