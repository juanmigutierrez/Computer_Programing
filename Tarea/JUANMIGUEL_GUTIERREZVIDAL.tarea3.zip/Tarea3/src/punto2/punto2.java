package punto2;
import acm.program.*;

public class punto2 extends ConsoleProgram{
	public void run() {
		Entero a = new Entero(5);
		Entero b = new Entero(7);
		println("El entero a es: "+a);
		println("El entero b es: "+b);
		a.suma(b);
		println("La suma del primer caso es"+a.suma(b));
		a.suma2(b);
		println("La suma del segundo caso es "+a.suma2(b));
	}

	

}
