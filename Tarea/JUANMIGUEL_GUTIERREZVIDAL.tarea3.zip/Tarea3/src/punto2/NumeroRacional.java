package punto2;


public class NumeroRacional {
	
	private int num; 
	
	private int den;
	
	/**
	 * Crea un n�mero rcional con numerador y denominador dados
	 * @param num numerador
	 * @param den denominador
	 */
	public NumeroRacional(int num, int den){
		this.num = num;
		this.den = den;
	}
	
	/**
	 * Crea un n�mero racional que representa un entero
	 * @param n n�mero entero
	 */
	public NumeroRacional(int n){
		this(n,1);
	}
	
	/**
	 * Crea un n�mero racional que representa el cero
	 */
	public NumeroRacional(){
		this(0);
	}
	
	/**
	 * Retorna la suma del n�mero racional r con este
	 * @param r n�mero racional a adicionar este
	 * @return suma del n�mero racional con este
	 */
	public NumeroRacional suma(NumeroRacional r){
		return new NumeroRacional(this.num*r.den + this.den*r.num,  this.den*r.den);
	}
	
	public String toString(){
		return this.num+"/"+this.den; 
	}
}
