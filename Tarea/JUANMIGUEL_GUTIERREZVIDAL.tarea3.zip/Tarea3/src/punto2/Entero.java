package punto2;

import punto2.NumeroRacional;

public class Entero {
	private int valor; 
	

	/**
	 * Crea un n�mero entero 
	 * @param valor valor del n�mero
	 */
	public Entero(int valor){
		this.valor = valor;
	}
	

	/**
	 * Crea un n�mero entero que representa el cero
	 */
	public Entero(){
		this(0);
	}
	
	/**
	 * Modifica el valor del entero
	 * @param valor valor a asignar
	 */
	public void setValor(int valor){
		this.valor = valor;
	}
	
	/**
	 * Retorna el valor del entero
	 * @return valor del entero
	 */
	public int getValor(){
		return this.valor;
	}
	
	public String toString(){
		return ""+this.valor; 
	}
	
	
	public Entero suma(Entero n) {
		Entero c = new Entero(this.getValor()+n.getValor());
		return c;
	}public Entero suma2(Entero n) {
		this.setValor(this.getValor()+n.getValor());
		return this;
		
	}

}
