package punto1;

import acm.program.ConsoleProgram;
import java.util.*;

import javax.swing.JFileChooser;
import java.util.Scanner;
import java.util.StringTokenizer;
import java.io.*;

public class punto1 extends ConsoleProgram {
	public void run(){
		println("Primero escja el archivo que va a a leer y despues la destinacion del archivo donde va guardar los datos");
		imprimir(escoger());
		
	}public void imprimir(String z) {
		JFileChooser fChooser = new JFileChooser(); 
		int result = fChooser.showSaveDialog(this);
		if(result == JFileChooser.APPROVE_OPTION){
			File archivo = fChooser.getSelectedFile();
			try{
				FileWriter fWriter = new FileWriter(archivo);
				PrintWriter writer = new PrintWriter(fWriter);
				writer.println(z);
				writer.close();
			}catch(IOException e){
				println("EL archivo pudo escribirse");
			}
		}
		
	}
	
	
	public String escoger() {
    int suma = 0;
	JFileChooser fChooser = new JFileChooser(); 
		int result = fChooser.showOpenDialog(this);
		if(result == JFileChooser.APPROVE_OPTION){
			File archivo = fChooser.getSelectedFile();
			try{
				FileReader fReader = new FileReader(archivo);
				Scanner sc = new Scanner(fReader);
				while(sc.hasNextLine()){
					String palabra = sc.next();
					boolean espalindromo = palindromo(palabra);
					if(espalindromo==true) {
						suma = suma +1;
						
					}println("La cantidad de palindromos son "+ suma);
				}
				sc.close();
				fReader.close();
				
			}catch(FileNotFoundException e){
				println("EL archivo no se encontr�");
			}catch(IOException e){
				println("EL archivo pudo leerse");
			}
		} return "La cantidad de palindromos son "+suma;
	}
	
	private boolean palindromo(String n) {
		int largo = n.length();
		int i = 0;
		int limite = (largo-1)/2;
		while(n.charAt(i)==n.charAt(largo-1) && i != limite && n.length()>2) {
			largo = largo-1;
			i = i+1;
         }if(i == limite && n.length()>2) {
        	 println(n+ " = Es un palindromo");
        	 return true;
         }else {
        	 println(n+ " = No es un palindronomo");
        	 return false;
         }
       }	
}
