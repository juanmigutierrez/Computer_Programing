package punto1;
import acm.program.*;

public class palindronomo extends ConsoleProgram {
	public void run() {
		String palindronomo1 = "reconocer";
		palindromo(palindronomo1);
		
		
		
	}private boolean palindromo(String n) {
		int largo = n.length();
		int i = 0;
		int limite = (largo-1)/2;
		while(n.charAt(i)==n.charAt(largo-1) && i != limite) {
			println("Cumplio");
			largo = largo-1;
			i = i+1;
         }if(i == limite) {
        	 println("Es un palindromo");
        	 return true;
         }else {
        	 println("No es un palindronomo");
        	 return false;
         }
       }
       }
	  

	
	


