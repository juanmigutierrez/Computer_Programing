package punto2;

public class MonedaCollecionable extends Coleccionable {
	private String pais_procedencia;
	private int ano_emision;
	private String denominacion;
	
	public MonedaCollecionable(String nombre, int id, String colleccion, String pais_procendencia, int ano_emision, String denominacion ) {
		super(nombre,id,colleccion);
		this.pais_procedencia = pais_procedencia;
		this.ano_emision = ano_emision;
		this.denominacion = denominacion;
	}public String getpais_procedencia() {
		return pais_procedencia;
	}public int ano_emision() {
		return ano_emision;
	}public String getdenominacion() {
		return denominacion;
	}public String toString() {
		return "Esta coleccion posee" +"el nombre:"+this.getnombre() +", el ID "+ this.getid() +",la collecion"+ this.getcolleccion() +"Viene del pais"+ pais_procedencia +" su ano de emision fue  "+ ano_emision +" y por ultimo su denomicacion su denominacion es "+ denominacion;
	}
}


