package punto2;

public class Coleccionable {
	private String nombre;
	private int id;
	private String colleccion;
	
	public Coleccionable(String nombre, int id ,String colleccion) {
		this.nombre = nombre;
		this.id =id;
		this.colleccion = colleccion;
	} public String getnombre(){
		return nombre;
	} public int getid() {
		return id;
	} public String getcolleccion(){
		return colleccion;	
	}public String toString(){
		return"Esta coleccion posee el nombre"+ nombre +" mas el ID "+ id +"y pertenece a la collecion"+colleccion;
	}

}
