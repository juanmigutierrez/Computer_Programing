package punto2;

public class FotoCollecionable extends Coleccionable {
	private String fecha;
	private String lugar;
	private String personasp;
	
	public FotoCollecionable( String nombre, int id, String colleccion, String fecha , String lugar, String personasp) {
		super(nombre,id,colleccion);
		this.fecha = fecha;
		this.lugar = lugar;
		this.personasp = personasp;
	}public String toString() {
		return "Este coleccionable posee el nombre "+this.getnombre()+" el ID" + this.getid()+ "pertenece a la coleccion"+this.getcolleccion()+" fue tomada en la fecha "+fecha +"en el lugar"+lugar+"Con estas personas"+personasp;
	}

}
