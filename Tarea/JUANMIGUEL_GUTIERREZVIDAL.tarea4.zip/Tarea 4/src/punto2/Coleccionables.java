package punto2;
import acm.program.*;

public class Coleccionables extends ConsoleProgram {
	public void run () {
		
	
	Coleccionable carritos = new Coleccionable("hotwells",1,"munecos");
	MonedaCollecionable dolar = new MonedaCollecionable("dolar",2,"moneda","USA",1957,"USD");
	FotoCollecionable micasa = new FotoCollecionable("micasa",3,"foto","10/08=2012/","micasa","miguel,jose,daniel");
	
	println(carritos);
	println(dolar);
	println(micasa);
	
	}
	

}
